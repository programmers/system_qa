#!/bin/bash

curl -sL https://github.com/shyiko/jabba/raw/master/install.sh | bash

bash $HOME/.jabba/jabba.sh