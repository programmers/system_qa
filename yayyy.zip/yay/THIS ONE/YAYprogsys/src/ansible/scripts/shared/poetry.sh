#!/bin/bash

curl -sL https://raw.githubusercontent.com/python-poetry/poetry/master/get-poetry.py | python