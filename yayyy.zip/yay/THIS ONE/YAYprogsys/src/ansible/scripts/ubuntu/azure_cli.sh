#!/bin/bash

curl -sL https://aka.ms/InstallAzureCLIDeb | bash