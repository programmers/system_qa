# Development Guide

Welcome to the development guide! This document is designed to provide a comprehensive overview of the technical details of the system, in a format that can be referred back to as needed. This guide aims to use clear language and "narrative" style overviews of essential concepts to lessen the learning curve for new contributors.

## Contents 

- [Design Goal](#design-goal)
- [Ecosystems](#ecosystems)
- [Current OS Support](#current-os-support)
- [Ansible](#ansible)
- [Playbooks](#playbooks)
- [Codebase](#codebase)
- [Scripting](#scripting)
  - [Layout](#layout)
  - [Runscript](#runscript)
    - [Creates Examples](#creates-examples)
        - [Scripts By Example](#writing-scripts-by-example)
        - [Java: Gradle](#java-gradle-good-example-of-using-trap)
        - [Python: Poetry](#python-poetry-shared-one-liner-via-python-execution)
        - [C/C++: Eclipse](#cc-eclipse-somewhat-involved-with-a-desktop-entry)
- [Main Function](#main-function)
  - [verify_operating_system function](#verify_operating_system-function)
  - [run_base_setup_script function](#run_base_setup_script-function)
  - [src/setup target](#flow-of-the-script-targeting-srcsetup)
- [The CLI](#the-cli)
  - [Selection](#selections)
  - [Tags (simple example)](#tags-simple-example)
  - [Tags (more involved example)](#tags-more-involved-example)
- [Running](#running)
  - ["Parent" Playbook](#parent-playbook)
  - [Command Execution](#command-execution)
- [Default Editor](#default-editor)
- [Releases](#releases)


</br>

# Design Goal

To maintain a lightweight solution with a small Python codebase, clear interfaces, reusability, extensibility, established operating system support, idempotency, and the reliability of the battle-tested Ansible provisioning system. Safety is a critical component, which is achieved through routine audits of all software and package sources.

The design decisions of Programmer's System provide the perfect choice for robustly provisioning a local development machine. Users will maximize their productivity and developer experience by following helpful prompts in the CLI and wait for Ansible to take care of the rest.

# Ecosystems 

- `General` (default)
- `Python`
- `JavaScript & Node`
- `Web`
- `Version Control`
- `Database Clients`
- `Containers & VMs`
- `Cloud`
- `Java`
- `C/C++`
- `Go`
- `PHP`
- `Rust`
- // Incomplete: "Ruby", "Scientific"
- // Wanted: "Mobile"

# Current OS Support

- `Ubuntu`
- `Mint Mate 21`
- `Fedora 37`
- MacOS (Up next!)

# Ansible

Ansible is widely regarded as one of the most reliable and mission-critical tools for all matters concerning cloud or on-prem systems infrastructure. It is regularly employed for server provisioning, configuration management, and orchestration.

Outside of those contexts, it can also be used to provision local machines using a small subset of its features. This includes the targeting of various Linux distributions and MacOS releases using popular, built-in packaging modules and a custom script module.

# Playbooks

Called "Ecosystems" in the README/CLI, Ansible Playbook files use YAML and Jinja 2 markup to provide a comprehensive set of instructions for the installation and configuration of software and packages. The abridged code below illustrates the overall structure of a playbook, with the inclusion of "narrative" comments to make the code and syntax easier to understand. "Playbook” will be used instead of "Ecosystem” from this point on.

In the most fundamental sense, a playbook contains a list of "tasks” that contain "modules". This allows the author to configure the parameters needed to define how the overview playbook should run. The modules used in this project include `apt`, `yum`/`dnf`, `snap`, `npm`, `brew`, `gem`, a custom runner, and more.

Below is the full, annotated Ubuntu/Mint "Database Clients.yml" playbook. The tasks, modules, and general "anatomy" of the playbook are detailed with comments throughout.

<br/>

```yml
---
# These are strictly DB clients. Programmer's System doesn't installs engines (or their configurations) of any kind.
- name: Database Clients
  hosts: localhost # always local

  # List of small units that encompass modules. Takes in many parameters.
  # We're using apt_repository, apt, runscript, snap, pip, and npm in this Playbook
  tasks:
    # DBeaver isn't included in Ubuntu sources so this will add the
    # official repository using the apt_repository module
    - name: DBeaver Repository
      apt_repository: repo=ppa:serge-rider/dbeaver-ce
      tags:
        - default # will always run

      # DBeaver's repository has been added, install it with apt module
    - name: DBeaver Community
      apt: name=dbeaver-ce # notice the simple parameter syntax
      tags:
        - default

      # The following "runscript" module will be discussed later. For now, notice
      # how program "Usql" targets a custom script "usql.sh" for install and
      # specifies "/usr/bin/usql" as the install location. Given a successful run,
      # this task will be skipped on reruns, assuming that the path/binary are present.
    - name: Usql
      runscript:
        script: usql.sh
        creates: /usr/bin/usql
      tags:
        - defaulXUbuntut

      # Using the snap module is preferred in this case, as it's the official install type 
    - name: Datagrip Trial
      snap: name=datagrip classic=yes
      tags:
        - datagrip_trial # runs based on CLI selections (more on this later)

      # Similar to Datagrip, Workbench's snap is the most reliable option at this time
    - name: MySQL Workbench Community
      snap: name=mysql-workbench-community classic=yes
      tags:
        - mysql # runs based on shared "key" CLI selections (all tags below are like this!)

      # Task that uses the pip module to install the handy mycli tool
    - name: mycli
      pip: name=mycli
      tags:
        - mysql

    - # Similar to the "DBeaver Repository" task, but for a security key
      name: pgAdmin 4 Desktop Key
      apt_key: url=https://www.pgadmin.org/static/packages_pgadmin_org.pub
      tags:
        - postgres

      # Similar to the "DBeaver Repository" task
    - name: pgAdmin 4 Desktop Repository
      apt_repository:
        repo: deb https://ftp.postgresql.org/pub/pgadmin/pgadmin4/apt/jammy pgadmin4 main
      tags:
        - postgres

      # We now can install pgAdmin. Notice how a linked package is specified
      # in the form of an array
    - name: pgAdmin 4 Desktop
      apt:
        pkg:
          - libpq5
          - pgadmin4-desktop
      tags:
        - postgres

      # CLI tool for Postgres
    - name: pgcli
      apt: name=pgcli
      tags:
        - postgres

      # Similar to prior examples, we must add a repo to install SQLite Browser
    - name: SQLite Browser Repo
      apt_repository: repo=ppa:linuxgndu/sqlitebrowser
      tags:
        - sqlite

      # Can now be installed
    - name: SQLite Browser
      apt: name=sqlitebrowser
      tags:
        - sqlite

      # The npm module is used for global installs of GUIs and CLIs
    - name: Redis Commander
      npm: name=redis-commander global=yes
      tags:
        - redis

      # Modules are very versatile. For instance, apt understands how to resolve
      # installing from remote deb files at a specific version
    - name: MongoDB Compass
      apt: deb=https://downloads.mongodb.com/compass/mongodb-compass_1.30.1_amd64.deb
      tags:
        - mongodb
```

# Codebase

Before delving deeper into the documentation, the codebase structure should be presented and explained for better context.
 
```
project tree
│
│   # Versioned documentation
├── docs
│   ├── Dev-Guide.md # you are here 
│   ├── Post-Install.md
│   └── Catalog.md
│
│   # Versioned visual assets
├── img
│   ├── demo.gif
│   └── logo.jpg
│
├── LICENSE
│
│   # This is the entry point script that performs validation, installs the
│   # operating's systems base/essential dependencies, presents the CLI and
│   # runs then passes the generated command string to Ansible.
├── run.sh 
│
├── README.md
│
└── src
    │   # Our all-local solution differs greatly from traditional Ansible
    │   # project use cases, so the layout is purposefully slimmed down.
    ├── ansible
    │
    │   # The ansible.cfg config file is read on startup to control
    │   # Ansible behavior. Sections contain name/value pairs for options,
    │   # such as forks, playbooks data, log verbosity, network settings, 
    │   # and retry specs.
    │   ├── ansible.cfg
    │   │  
    |   |  # Ansible provides developers with an easy-to-use Python API,
    |   |  # that allows them to extend its many components, resulting in 
    |   |  # more capabilities in their playbooks and elsewhere. These custom 
    |   |  # modules will be discussed in detail later in the guide.
    │   ├── modules
    │   │   ├── runscript.py
    │   │   └── vscodeextension.py
    │   │     
    │   │   # Each OS gets their playbook directory.
    │   ├── playbooks
    │   │   │ 
    │   │   │   # If there is a devired system such as a Linux Mint release, it
    │   │   │   # will uses its "parent" directory (Ubuntu, in this example).
    │   │   └── ubuntu
    │   │   │   ├── C and Cpp.yml
    │   │   │   ├── Cloud.yml
    │   │   │   ├── Containers and VMs.yml
    │   │   │   ├── Database Clients.yml
    │   │   │   ├── ...
    │   │   │   ├── ...
    │   │   │   ├── ...
    │   │   │   ├── ...
    │   │   │   └── ...
    │   │   └── fedora    
    │   │   │    ├── ...
    │   │   │    ├── ...    
    │   │   │    ├── ...    
    │   │   │    ├── ...    
    │   │   │    └── ...
    │   │   └── macos    
    │   │        ├── ...
    │   │        ├── ...    
    │   │        ├── ...    
    │   │        ├── ...    
    │   │        └── ...
    │   │
    │   │   # This is a generated script that targets (also generated) run_playbooks.yml
    │   │   # This includes the selected playbooks for execution and the tags. 
    │   ├── run_ansible.sh
    │   │
    │   │   # Each OS gets their scripts directory, unless a script is shared.
    │   ├── scripts
    │   │   │
    │   │   │   # These are scripts that are OS agnostic
    │   │   └── shared
    │   │   │   ├── composer.sh
    │   │   │   ├── gvm.sh
    │   │   │   ├── poetry.sh
    │   │   │   ├── ...    
    │   │   │   ├── ...
    │   │   │   ├── ...
    │   │   │   ├── ...
    │   │   │   └── ...
    │   │   │
    │   │   │   # Similar to the "playbooks" directory style, each OS gets their
    │   │   │   # own scripts area. The same rules apply with "devired" systems.
    │   │   └── ubuntu
    │   │   │    ├── aws_cli.sh
    │   │   │    ├── azure_cli.sh
    │   │   │    ├── clang_llvm.sh
    │   │   │    ├── docker_compose.sh
    │   │   │    ├── eclipse_cpp.sh
    │   │   │    ├── ...    
    │   │   │    ├── ...    
    │   │   │    ├── ...    
    │   │   │    ├── ...    
    │   │   │    └── ...
    │   │   └── fedora    
    │   │   │    ├── ...
    │   │   │    ├── ...    
    │   │   │    ├── ...    
    │   │   │    ├── ...    
    │   │   │    └── ...
    │   │   └── macos    
    │   │        ├── ...
    │   │        ├── ...    
    │   │        ├── ...    
    │   │        ├── ...    
    │   │        └── ...
    │   │
    │   │   # This holds metadata on the OS, regular user, and more. 
    │   │   # These values are primarily used in the custom modules.
    │   └── vars.yml
    │
    │   # The CLI provides prompts the user about which "ecosystems" (playbooks)
    │   # they want and then asks questions about their needs based on prior selections.
    │   # This piece is handled in the Python codebase and uses the "inquirer" package.
    ├── cli
    │   ├── prompt.py
    │   ├── questions.py
    │   └── theme.py
    │  
    │   # Routes calls to either present the CLI or generate Ansible assets. 
    ├── main.py
    │   
    └── setup
        │   # Essential functions that generate all assets for Ansible.
        ├── assets.py
        │  
        │   # The "base" installers that run when an OS is provided (base packages).
        ├── assets.py
        ├── fedora.sh
        ├── macos.sh (soon)
        └── ubuntu.sh
```

# Scripting

## Layout

It is best to use bash scripts to install software and packages in certain cases, including packages without valid repositories or those that can be only be installed using scripts. 

- `src/ansible/scripts/{OS}/`: holds OS-specific scripts. Similar to the "playbooks" directory, derived systems (such as Linux Mint instead of Ubuntu) will be resolved to the parent OS (Ubuntu, in this case).

- `src/ansible/scripts/shared/`: holds scripts that will work on any of the supported OSes.

## Runscript

`runscript` is a custom Ansible module (`src/ansible/modules/modules/runscripts.py`) that handles all script execution in the playbooks. It is very useful as it can run a target script as the regular user or root user based on the install context. By following bash best practices, this module can accurately detect already-installed software and packages, point to shared or OS-specific scripts, and accept a useful shorthand syntax to operate out of the user's home directory. Here are the module parameters:

- `script`: The script name (no path is needed - it is inferred). Examples to come..

- `shared`: If `true`, the supplied bash script will be executed in `src/ansible/scripts/shared/`, else, it will use `src/ansible/scripts/{OS}/`.

- `creates`:

  - This parameter allows the programmer to easily specify the location of a binary, file, or directory that only the script can create. A comprehensive search is ran when this module is executed to see if said asset exists. If found, the task will be skipped. This is very useful in ensuring idempotency on playbook reruns.

  - When it comes to shorthand, non-root contexts, the package `sometoolhere` may be identified in the `home` directory such as `/home/theuser/.sometoolhere` his parameter (i.e.: `creates: .sometoolhere`), the module will translate to `/home/theuser/.sometoolhere` behind the scenes. This package belows to the regular user. This serves as a nice shorthand/abstraction. Many examples are provided in the following section.

  - When `.` isn't present, such as with `/usr/local/bin/composer` below, this informs the module to execute the script as root, given the install context is system wide. The following examples will make sense of this context.

<br/>

## Creates Examples

<br/>

_(Note: these examples are from various playbooks)_

<br/>

_(shared - root user)_

```yml
# The script to run resolves to src/ansible/scripts/shared/composer.sh
- name: Composer
  runscript:
    script: composer.sh
    shared: true
    creates: /usr/local/bin/composer # system-wide
```

_(not shared - root user)_

```yml
# The script to run resolves to src/ansible/scripts/{OS}/eclipse_java.sh
- name: Eclipse
  runscript:
    script: eclipse_java.sh
    creates: /usr/bin/eclipse # system-wide
```

_(not shared - regular user)_

```yml
# The script to run resolves to src/ansible/scripts/{OS}/jabba.sh
- name: Jabba (Java) Version Manager
  runscript:
    script: jabba.sh
    creates: .jabba # resolves to /home/theuser/.jabba
```

_(shared - regular user)_

```yml
# The script to run resolves to src/ansible/scripts/shared/gvm.sh
- name: Go Version Manager
  runscript:
    script: gvm.sh
    creates: .gvm # resolves to /home/theuser/.gvm
    shared: true
```

<br/>

### Writing Scripts by Example

Writing scripts for `runscript` are straight forward. Keep these in mind:
- Be mindful of where you place your scripts:
    - `src/ansible/scripts/{OS}/` OS-specific.
    - `src/ansible/scripts/shared/`OS-agnostic
- Opt for using `/usr/local/bin/` for installs, when appropriate
- Outside of adding launchers, don't change the desktop environment
- Know how to use cURL and piping effectively (many existing examples)
- Use `TRAP … EXIT` if there is a chance that there will be left over artifacts
- If a sub shell must be launched, enter in an issue for discussion
- Be mindful of how your script will run with future OS releases
- use_underscores_in_script_names.sh

<br/>

_The following examples show the linked (commented out) task references that use `run_script`_.

<br/>

### Java: Gradle (good example of using trap)

```bash
# Task
"""
- name: Gradle
  runscript:
    script: gradle.sh
    creates: /usr/local/bin/gradle
  tags:
    - gradle
"""

# Script
trap "rm gradle.zip" EXIT

curl -sL https://services.gradle.org/distributions/gradle-7.2-bin.zip -o gradle.zip
unzip gradle.zip -d /usr/local/bin/gradle
```

### Python: Poetry (shared one-liner via Python execution)

```bash
# Task
"""
- name: Poetry
  runscript:
    script: poetry.sh
    creates: .poetry/bin/poetry
    shared: true
  tags:
    - poetry
"""

# Script
curl -sL https://raw.githubusercontent.com/python-poetry/poetry/master/get-poetry.py | python
```

### C/C++: Eclipse (somewhat involved with a desktop entry)

```bash
# Task
"""
- name: Eclipse C++
  runscript:
    script: eclipse_cpp.sh
    creates: /usr/bin/eclipse-cpp
  tags:
    - eclipse_cpp
"""

# Script
trap "rm -rf eclipse" EXIT

curl -sL https://download.eclipse.org/technology/epp/downloads/release/2022-09/M2/eclipse-cpp-2022-09-M2-linux-gtk-x86_64.tar.gz | tar -zx

mv eclipse /usr/bin/eclipse-cpp

cat << 'EOF' >> /usr/share/applications/eclipse-cpp.desktop
[Desktop Entry]
Encoding=UTF-8
Name=Eclipse C++
Comment=Eclipse for C++ developers
Exec=/usr/bin/eclipse-cpp/eclipse
Terminal=false
Type=Application
Categories=Utility;Development;
EOF
```

# Main Function

When running Programmer’s System, one must call the `./run.sh` entry-point script to begin the install process. If all installation steps are satisfied, the prompt CLI will be presented.

The `main` function is comprised of specific functions to carry out this process. It is organized in a "try/catch" block.

```bash
# main function
{
	verify_command &&
	verify_operating_system &&
	run_base_setup_script &&
	python src/main.py $operating_system &&
	run_ansible
} || {
    echo "Error with Ansible run..."
    exit 1
}
```

## verify_operating_system function

This command is very important when starting execution. It is responsible for establishing which operating system to use. It also checks to see if the operating system that is passed in is a "derived” one. The code is very simple:

```bash
# 1) Check lists to set a derived OS to the parent
if [[ ## Ubuntu ##
	"$operating_system" == "mint-mate" ||
	"$operating_system" == "mint-xfce" ||
	"$operating_system" == "mint-cinnamon"
	]];
then
	    operating_system="ubuntu"
fi
```

We know that Linux Mint systems are based on Ubuntu, so the variable is set to Ubuntu. This allows contributors to test and add derived systems without having to create totally different playbooks and scripts. This OS variable can be thought of as a "global” hereafter.

There is a comment underneath this code that says that one can add more systems in this manner.

<br/>

## run_base_setup_script function

Each OS has a setup script in `src/setup/{OS}`. These install the "base” system dependencies and prepares certain parameters. Once done, one can run the CLI and, in turn, Ansible.

<br/>

## Flow of the script, targeting src/setup/

1. Perform apt updates
2. Installs essential packages
3. Installs the latest Python (from the trusted "deadsnakes” PPA). (Note that this project mostly uses Python!)
4. Installs `snapd`, if not present
5. Installs Python Inquirer (the package behind the CLI)
6. Installs the latest Ansible from its official PPA
7. Constructs the Ansible config file `/src/ansible/ansible.cfg`
8. Registers the custom Ansible modules
9. Stores a `vars.yml` file with all needed variables for operations
10. Creates a lock file if all operations succeeded

# The CLI 

## Selections

`python src/main.py {OS}` is called from the bash script to allow users to select their playbooks and answer many questions based on their needs. This is handled by Python’s `Prompt` class (`src/cli/prompt.py`). Selections are presented as checkboxes through this easy to use CLI.

The logic surrounding the CLI isn't very notable and can be skipped. The most important aspect is understanding the CLI's data structure and how to add new entries. This enables Programmer's System to be highly configurable.

Each CLI question is stored in the `src/cli/questions.py` dictionary (this is worth scanning). The following is an isolated example of the version control section of the CLI's data structure. Assuming the user selected the "Version Control" playbook, they will be presented with question surround which version control system(s) they use as well as their favorite merge tool. The user can select as many options as they wish and then will continue through the CLI process, which relies on this simple dictionary structure. The key `tags` seen below will be explained in great detail in the following sections.


```python
"Version Control": [
    {
        "key": "version_control_systems",
        "type": "checkboxes",
        "question": "Select the version control systems you use",
        "tags": [
            ( "Git", "git" ),
            ( "Mercurial",  "mercurial" ),
            ( "Subversion", "subversion" ),
            ( "CVS", "cvs" )
        ]
    },
    {
        "key": "merge_tools",
        "type": "checkboxes",
        "question": "Select the merge/compare software you use (if unsure, consider Meld)",
        "tags": [
            ( "Meld", "meld" ),
            ( "KDiff3", "kdiff3" )
        ]
    },
]
```

<br/>

## Tags (simple example)

Consider how tags can be represented in the Java playbook via the CLI's `src/cli/questions.py` dictionary:

The data from the CLI:

```python
{
  "key": "java_build_tools",
  "type": "checkboxes",
  "question": "Select the Java build tools you use",
  "tags": [
     ( "Maven", "maven" ),
     ( "Gradle", "gradle" )
  ]
}
```

The relevant tasks (with tags) in the Java playbook:

```yml
- name: Maven
  apt: name=maven
  tags:
    - maven
  
- name: gradle
  apt: name=gradle
  tags:
    - gradle
```

Based on what the user specified, this is what `ansible-playbook` could reference in `--tags` when ran:

- `--tags="gradle"`
- `--tags="maven"`
- `--tags="gradle,maven"`
- `--tags=""`

<br/>

## Tags (more involved example)

Here we find the structure in the CLI code that maps questions to tags that maps for Database Clients. As previoulsy mentioned, CLI's data structure found here: `src/cli/questions.py` for a recap:


```python
{
  "key": "database_clients",
  "type": "checkboxes",
  "question": "Select the database systems you use",
  "tags": [
      ( "MySQL", "mysql" ),
      ( "Postgres", "postgres" ),
      ( "Sqlite", "sqlite" ),
      ( "Redis", "redis" ),
      ( "MongoDB", "mongodb" )
  ]
}
```

The relevant tasks will map to those selection in the playbook:

```yml
  - name: MySQL Workbench Community
    snap: name=mysql-workbench-community classic=yes
    tags:
      - mysql

  - name: mycli
    pip: name=mycli
    tags:
      - mysql

  - name: pgAdmin 4 Desktop Key
    apt_key: url=https://www.pgadmin.org/static/packages_pgadmin_org.pub
    tags:
      - postgres

  - name: pgAdmin 4 Desktop Repository
    apt_repository:
      repo: deb https://ftp.postgresql.org/pub/pgadmin/pgadmin4/apt/jammy pgadmin4 main
    tags:
      - postgres

  - name: pgAdmin 4 Desktop
    apt: 
      pkg:
        - libpq5
        - pgadmin4-desktop
    tags:
      - postgres

  - name: pgcli
    apt: name=pgcli
    tags:
      - postgres

  - name: SQLite Browser Repo
    apt_repository: repo=ppa:linuxgndu/sqlitebrowser
    tags:
      - sqlite

  - name: SQLite Browser
    apt: name=sqlitebrowser
    tags:
      - sqlite

  - name: Redis Commander
    npm: name=redis-commander global=yes
    tags:
      - redis

  - name: MongoDB Compass
    apt: deb=https://downloads.mongodb.com/compass/mongodb-compass_1.30.1_amd64.deb
    tags:
      - mongodb
```

**Conclusion**: Tags are of great importance. Certain playbooks contain a wide range of software and packages that can be selected. As shown above, some tasks shared the same tags, ensuring a given installation process is followed.

# Running

The last function in `./run.sh` is `run_ansible`. It calls the generated `src/ansible/run_ansible.sh` with all parameters needed to execute the primary Ansible command: `ansible-playbook`. Parameters include the target playbook file, known as the "parent playbook" as well as selected tags.

<br/>

## "Parent" Playbook

`run_playbooks.yml` is generated based on the playbooks selected in the CLI. It is a "parent" playbook that informs Ansible (through the `ansible-playbook` command) which playbooks to run. 

This example file (located at `src/ansible/playbooks/{OS}/run_playbooks.yml`) "tell" Ansible which which playbooks to run:

```yml
- import_playbook: "General.yml"
- import_playbook: "Python.yml"
- import_playbook: "Web.yml"
- import_playbook: "Version Control.yml"
```

(Note that tags are not referenced in the parent playbook file. They are passed in via an arg, which may be confusing at first. The following section shows said arg.)

<br/>

## Command Execution

Putting together all of the concepts, the following is a complete example of the command given the parent playbook target and the tags:

```bash
sudo ansible-playbook ~/.progsys/src/ansible/playbooks/ubuntu/run_playbooks.yml --tags="pipenv,pycharm,react,angular,git,subversion"
```

# Default Editor

Next to the `runscript` module that is documented in the **Scripting** section, there is another custom module, `vscodeextension` (`src/ansible/modules/vscodeextension.py`), that installs VSCode extensions.

**Why VSCode?**: VSCode is a reliable and powerful source code editor in the modern times. Almost all playbooks interface with it in terms of installing relevant and capable extensions. Programmer’s System wouldn't be very useful without a well equipped editor that is related to each playbook out of the box.

Many IDEs are readily available for selection in the CLI, making the use of VSCode optional. Note that the author of this guide uses a Vim emulator in VSCode full-time but cannot evaluate the quality of Emacs emulator/mappers. This may be seen as a common ground for these popular editors.

With that said, here are VSCode Extensions usage examples from various playbooks:

```yml
- name: VSCode Vue
  vscodeextension: name=hollowtree.vue-snippets
    
- name: VSCode React
  vscodeextension: name=jawandarajbir.react-vscode-extension-pack

- name: VSCode TypeScript
  vscodeextension: name=loiane.ts-extension-pack
```

# Releases

Given that operating systems upgrade quickly (through patches or major releases), it is essential for us to employ the use of "Git Release Tags" in order to "snapshot" a given release at a specific point in time to ensure compatibility.