import yaml

from pathlib import Path

# See docs/Dev-Guide.md for all information
def generate_assets(playbooks, operating_system, tags):
    parent_playbooks_file = str(Path(f'src/ansible/playbooks/{operating_system}/run_playbooks.yml').resolve())

    # Creates the script with the command that Ansible will run
    with open("src/ansible/run_ansible.sh", "w") as run_file:
        tags_as_str = ','.join(tags)
        call_str = ' '.join([
            '#!/bin/bash\n', 'sudo',
            'ANSIBLE_LOCALHOST_WARNING=false', 'ansible-playbook', parent_playbooks_file, f'--tags="{tags_as_str}"'
        ])

        run_file.write(call_str)

    # Generates the "parent" playbook file with the playbooks to target
    with open(parent_playbooks_file, "w") as parent_file:
        playbooks.insert(0, "General") # add base playbook

        yaml_header = "---"
        yaml_imports = [f'\n- import_playbook: "\'{playbook}.yml\'"' for playbook in playbooks]
        yaml_as_str = "".join(yaml_imports)

        parent_file.write(yaml_header + yaml_as_str)
