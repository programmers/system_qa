#!/bin/bash

cli_command=$1
operating_system=$2

show_command_options () {
	echo "Welcome! Select your operating system and for setup:"
	echo ""
	echo "  ./run.sh setup ubuntu"
	echo "  ./run.sh setup xubuntu"
	echo "  ./run.sh setup mint-mate"
	echo "  ./run.sh setup mint-xfce"
	echo "  ./run.sh setup mint-cinnamon"
	echo "  ./run.sh setup fedora"
	echo "  ./run.sh setup macos"
	exit 1
}

verify_command () {
	if  [ "$cli_command" != "setup" ]; then
		show_command_options 
	fi
}

verify_operating_system () {
	# 1) Check lists to set a derived OS to the parent
	if [[ ## Ubuntu ##
			"$operating_system" == "mint-mate" ||
			"$operating_system" == "mint-xfce" ||
			"$operating_system" == "mint-cinnamon" ||
			"$operating_system" == "xubuntu"
		]];
	then
	    operating_system="ubuntu"
	fi

	# ...
	# [More derived OS checks here!]
	# ...


	# 2) Check the resolved variable against available operating systems
	if ! [[
			$operating_system == "ubuntu" ||
			$operating_system == "macos"  ||
			$operating_system == "fedora"
		 ]];
	then
		show_command_options 
	fi
}

run_ansible () {
	# move to ansible's working dir and prompt for elevation
	cd src/ansible 
	exec sudo bash run.sh
}


run_base_setup_script () {
	if [ ! -f src/setup/lock ]; then
		{
			echo "Running setup for target '"$operating_system"'"
			bash "./src/setup/"$operating_system".sh" > /dev/null # silent - only showss stderr
		} || {
			echo "Error with '"$operating_system"' base install..."
			exit 1
		}
	fi
}

# main
{
	verify_command &&
	verify_operating_system &&
	run_base_setup_script &&
	python src/main.py $operating_system &&
	run_ansible
} || {
    echo "Error with Ansible run..."
    exit 1
}
