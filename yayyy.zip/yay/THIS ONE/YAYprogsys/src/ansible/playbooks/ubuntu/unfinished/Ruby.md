## Incomplete Ruby Playbook

Contributions welcome! This playbook has all of the desired Ruby dev software and packages,
however, a best practice is difficult to implement: installing the latest Ruby via rvm. 

While the Ruby shim is global, the remaining scripts that depend on it aren't
using it. Manually spawning new shells (or even sourcing) are a very bad idea.

These are the software and packages list:

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>About</th>
      <th>Website</th>
      <th>Guide</th>
      <th>License</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Ruby Rvm</td>
      <td>Ruby version manager</td>
      <td><a href="https://rvm.io/">link</a></td>
      <td><a href="#">none</a></td>
      <td>MIT</td>
    </tr>
    <tr>
      <td>VSCode Ruby</td>
      <td>Primary Ruby VSCode extension</td>
      <td><a href="https://github.com/rubyide/vscode-ruby">link</a></td>
      <td><a href="https://marketplace.visualstudio.com/items?itemName=rebornix.Ruby">link</a></td>
      <td>MIT</td>
    </tr>
    <tr>
      <td>Bundler</td>
      <td>Package Manager</td>
      <td><a href="https://github.com/rubygems/rubygems">link</a></td>
      <td><a href="#">none</a></td>
      <td>MIT</td>
    </tr>
    <tr>
      <td>RubyMine Trial</td>
      <td>JetBrains IDE trial</td>
      <td><a href="https://www.jetbrains.com/rubymine">link</a></td>
      <td><a href="https://www.jetbrains.com/help/ruby/get-started.html">link</a></td>
      <td>Paid</td>
    </tr>
  </tbody>
</table>


## Tasks & Scripts

### RVM

```
# Task
- name: rvm
  runscript:
    script: rvm.sh
    creates: /usr/share/rvm/bin/rvm
  tags:
    - default
```

```
# Code
curl -sSL https://rvm.io/mpapis.asc | gpg --import -
curl -sSL https://rvm.io/pkuczynski.asc | gpg --import -
curl -sSL https://get.rvm.io | bash -s stable

rvm install 3.1.2
rvm use 3.1.2
```

### VSCode Ruby Extension

```
# Task
- name: VSCode Ruby
  vscodeextension: name=rebornix.Ruby
  tags:
    - default
```

### Bundler

```
# Task
- name: Bundler
  runscript:
    script: bundler.sh
    creates: /usr/share/rvm/gems/ruby-3.1.2/bin/bundler
  tags:
    - default
```

```
# Code
gem install bundler
```

### RubyMine Trial

```
# Task
- name: RubyMine Trial
  snap: name=rubymine classic=yes
  tags:
    - rubymine_trial
```
