#!/bin/bash

curl -sL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash