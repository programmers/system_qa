## Incomplete Scientific Playbook

Contributions welcome! In short, there is no obvious way to situate all of this...

Either the software is massive or there's too many choices that could go into the CLI (bad UX)


These are the software and packages list:

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>About</th>
      <th>Website</th>
      <th>Guide</th>
      <th>License</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Anaconda</td>
      <td>Scientific platform with 250 packages and thousands more (using Conda)</td>
      <td><a href="https://www.anaconda.com">link</a></td>
      <td><a href="#">none</a></td>
      <td>Free/Paid</td>
    </tr>
    <tr>
      <td>Miniconda</td>
      <td>Light version of Anaconda for those that want to individually choose packages (using Conda)</td>
      <td><a href="https://docs.conda.io/en/latest/miniconda.html">link</a></td>
      <td><a href="#">none</a></td>
      <td>Free/Paid</td>
    </tr>
  </tbody>
</table>


**Core Debian/Ubuntu Scientific Software and Packages**

These packages all start with "science-*". They are installable them with apt-get.

Sources:
- https://wiki.debian.org/DebianScience/
- https://help.ubuntu.com/community/UbuntuScience

It isn't feasible at ALL to include the selection of these in the CLI. Not only are there
just too many topics here, some software and packages are massive.

Perhaps there can be some documentation/scripts around these for the user to install stuff sort-of manually???

<table>
  <tbody>
    <tr>
      <td>chemistry</td>
      <td>dataacquisition</td>
    <tr>
    <tr>
      <td>distributedcomputing</td>
      <td>imageanalysis</td>
    </tr>
    <tr>
      <td>machine-learning</td>
      <td>numericalcomputation</td>
    </tr>
    <tr>
      <td>presentation</td>
      <td>simulations</td>
    </tr>
    <tr>
      <td>statistics</td>
      <td>typesetting</td>
    </tr>
    <tr>
      <td>viewing</td>
      <td>workflow</td>
    </tr>
    <tr>
      <td>biology</td>
      <td>economics</td>
    </tr>
    <tr>
      <td>electronics</td>
      <td>electrophysiology</td>
    </tr>
    <tr>
      <td>engineering</td>
      <td>financial</td>
    </tr>
    <tr>
      <td>geography</td>
      <td>geometry</td>
    </tr>
    <tr>
      <td>highenergy-physics</td>
      <td>linguistics</td>
    </tr>
    <tr>
      <td>logic</td>
      <td>machine-learning</td>
    </tr>
    <tr>
      <td>mathematics</td>
      <td>meteorology</td>
    </tr>
    <tr>
      <td>nanoscale-physics</td>
      <td>neuroscience-cognitive</td>
    </tr>
    <tr>
      <td>neuroscience-modeling</td>
      <td>numericalcomputation</td>
    </tr>
    <tr>
      <td>physics</td>
      <td>presentation</td>
    </tr>
    <tr>
      <td>psychophysics</td>
      <td>robotics</td>
    </tr>
    <tr>
      <td>simulations</td>
      <td>statistics</td>
    </tr>
    <tr>
      <td>tasks</td>
      <td>typesetting</td>
    </tr>
    <tr>
      <td>viewing</td>
      <td></td>
    </tr>
    </tr>
  <tbody>
<table>


## Tasks & Scripts

### Anaconda

```
# Task
- name: Anaconda
  runscript:
    script: anaconda.sh
    creates: .anaconda
  tags:
    - anaconda
```

```
# Code
trap "rm install.sh" EXIT

# NOTICE: Anaconda needs >=16 GB RAM, >= 300 GB Storage, and 2 modern CPUs:
# https://docs.anaconda.com/anaconda-enterprise/system-requirements/

curl -sL https://repo.anaconda.com/archive/Anaconda3-2021.11-Linux-x86_64.sh -o install.sh
bash install.sh -b -p $HOME/.anaconda

cat << 'EOF' >> $HOME/.bashrc
export PATH="$PATH:$HOME/.anaconda/bin"
EOF
```

### Miniconda

```
# Task
- name: Miniconda
  runscript:
    script: miniconda.sh
    creates: .miniconda
  tags:
    - miniconda
```

```
# Code
trap "rm install.sh" EXIT

curl -sL https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh -o install.sh
chmod +x install.sh
./install.sh -b -p $HOME/.miniconda

cat << 'EOF' >> $HOME/.bashrc
export PATH="$PATH:$HOME/.miniconda/bin"
EOF
```