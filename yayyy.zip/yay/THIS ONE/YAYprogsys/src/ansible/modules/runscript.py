#!/usr/bin/python

"""
There is a lot to this module. It is most technically complex code in the
project. The following high level information should aid in understanding
the logic as well as the various contexts.

------------------------------------
Playbook authors use this module to:
------------------------------------
  1. Execute scripts as the regular user instead of root (when needed)
  2. Avoid having to manually supply who will run the script
  3. Supply a boolean to target os-specific or shared scripts

--------------------------
Parameters for this module
--------------------------
  - script: os-specific target script that will be executed
  - creates: created asset whose presense determines execution
  - shared: sets the targets script's location outside of os scripts 

------------------------------
Note about "creates" shorthand
------------------------------
When "." is used with the "creates" parameter (i.e.: .helloprogram),
it will translate to /home/theuser/.helloprogram. This not only serves
as a nice shorthand, but also as a signal that determines if the script
should run a the regular user or root.

--------------------------------
Shared script example (non-root)
--------------------------------
- name: Go Version Manager
  runscript:
    script: gvm.sh
    creates: .gvm
    shared: true
  tags:
    - default

-------------------------------------
OS specific script example (non-root)
-------------------------------------
- name: Nvm
  runscript:
    script: nvm.sh
    creates: .nvm
  tags:
    - default

---------------------------------
OS specific script example (root)
---------------------------------
- name: Node
  runscript:
    creates: /usr/bin/node
    script: nodejs.sh
  tags:
    - default
"""

import subprocess
import yaml
import os

from pathlib import Path

from ansible.module_utils.basic import *

def get_vars():
    current_dir = Path(os.getcwd())
    ansible_dir = str(current_dir.parents[1]) 
    vars_path = f"{ansible_dir}/vars.yml"

    with open(vars_path) as f:
        return yaml.safe_load(f)

# resolves the os-specific and shared script paths
def get_script_paths(project_dir, operating_system, script):
    scripts = f"{project_dir}/src/ansible/scripts/{operating_system}/{script}"
    shared_scripts = f"{project_dir}/src/ansible/scripts/shared/{script}"

    return {
        'scripts': scripts,
        'shared_scripts': shared_scripts
    }

# if "." is present, the script will run as the regular user, else root.
def should_run_as_regular_user(creates):
    return creates[0] == '.'

def check_for_creates_target(creates, user):
    creates = creates.replace(' ','\ ') # escape spaces in dir

    if should_run_as_regular_user(creates):
        creates = f"/home/{user}/{creates}"

    # checks for the existence of the "creates" value
    is_file = os.path.isfile(creates)
    is_dir = os.path.isdir(creates)

    return is_file or is_dir

def main():
    module = AnsibleModule(argument_spec=dict(
        script=dict(type="str", required=True),
        creates=dict(type="str", required=True),
        shared=dict(type="bool", required=False)
    ))

    # extracts module values from the playbook
    script  = module.params['script']
    creates = module.params['creates']
    shared  = module.params.get("shared", False)

    try:
        vars = get_vars()

        # program installed, skip execution
        if check_for_creates_target(creates, vars['user']):
            module.exit_json(changed=False)

        # resolves the paths (conditionally sets the path to os-specific or shared)
        script_paths = get_script_paths(vars['project_dir'], vars['operating_system'], script)
        script_path = script_paths['shared_scripts'] if shared else script_paths['scripts']

        if should_run_as_regular_user(creates):
            # Ansible runs as sudo - this command allows for execution as the regular user
            # TODO: this may not work for every system!
            cmd = ["sudo", "-S", "-u", vars['user'], "-i", "/bin/bash", "-l", "-c", f"'{script_path}'"]
        else:
            # run the script as root
            cmd = [script_path]

        subprocess.run(
            cmd,
            stderr=subprocess.PIPE,
            stdout=subprocess.PIPE
        )

        module.exit_json(changed=True)

    except subprocess.CalledProcessError as call_err:
        module.fail_json(msg=f"Cannot call {script}. {str(call_err)}")
    except Exception as err:
        module.fail_json(msg=f"General issues when calling {script}. {str(err)}")

if __name__ == "__main__":
    main()