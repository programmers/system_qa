#!/bin/bash
 sudo ANSIBLE_LOCALHOST_WARNING=false ansible-playbook /home/mvimgnu/.progsys/src/ansible/playbooks/ubuntu/run_playbooks.yml --tags="flake8,black,pipenv,poetry,pyenv,pycharm,default"