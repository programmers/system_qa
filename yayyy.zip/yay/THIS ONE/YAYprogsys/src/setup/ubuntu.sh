#!/bin/bash

# find regular user and project dir
user=$(whoami)
user_dir="/home"/$user
project_dir=$user_dir"/.progsys"

# usual packages
sudo apt-get update -y
sudo apt-get install -y software-properties-common \
                        apt-transport-https \
                        build-essential \
                        ca-certificates \
                        curl \
                        wget
 
# Python (main lang)
sudo apt-add-repository -y ppa:deadsnakes/ppa
sudo apt-get update -y
sudo apt-get install -y python3.10 \
                        python3-pip \
                        python3-dev \
                        python3-setuptools \
                        python3-distutils \
                        python3-wheel \
                        python3-tk \
                        python-is-python3

# install snap if not present
if [ ! -f /usr/bin/snap ]; then
    sudo mv /etc/apt/preferences.d/nosnap.pref ~/Documents/nosnap.backup
    sudo apt-get update -y
    sudo apt-get install -y snapd
fi

# project deps
python -m pip install inquirer pyyaml

# Ansible (official ppa)
sudo apt-add-repository -y ppa:ansible/ansible
sudo apt-get update -y
sudo apt-get install -y ansible

# Ansible module location
cat > $project_dir"/src/ansible/ansible.cfg" <<EOF
[defaults]
library = $project_dir/src/ansible/modules/
EOF

# the "global" vars files
cat > $project_dir"/src/ansible/vars.yml" <<EOF
---
user: $user
project_dir: $project_dir
operating_system: ubuntu
EOF

cat > $project_dir"/src/ansible/modules/ansible.cfg" <<EOF
[defaults]
library = $project_dir"/src/ansible/modules/"
EOF


touch $project_dir"/src/setup/lock"