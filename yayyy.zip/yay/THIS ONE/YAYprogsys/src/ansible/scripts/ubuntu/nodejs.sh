#!/bin/bash

curl -sL https://deb.nodesource.com/setup_current.x | bash
apt-get install -y nodejs