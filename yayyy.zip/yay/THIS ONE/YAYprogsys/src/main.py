import sys

from cli.prompt import Prompt
from setup.assets import generate_assets

def main():
    operating_system = sys.argv[1:][0] # pre-validated

    try:
        prompt = Prompt()
        playbooks, tags = prompt.get_results()

        generate_assets(playbooks, operating_system, tags)
        sys.exit(0)
    except Exception as e:
        print(str(e))
        sys.exit(1)

main()