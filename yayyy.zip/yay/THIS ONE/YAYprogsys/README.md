
<p align="center">
  <img src="https://raw.githubusercontent.com/programmers/system_qa/main/img/logo.jpg" alt="logo">
</p>

# About

Reliably equip your fresh dev machine with industry-standard software and packages to reduce setup time, frustrations, and uncertain copy/pasting. The handy CLI allows one to specify their exact programming ecosystems and requirements.

<br/>

## Overview

This lightweight solution uses Python and Ansible to provision a local development machine, tailored to the specific needs of the user. Safety, comprehensive ecosystems, operating system support, extensibility, and idempotency are the core goals of this project. 

<br/>

**OS Support:** Ubuntu, Mint Mate (<u>TODO</u>: Fedora/Mac)

**Ecosystems:** General, Python, JavaScript & Node, Web, Version Control, Database Clients, Containers & VMs, Cloud, Java, C/C++, Go, PHP, Rust

**Modules Support** Some modules in use are apt, yum/dnf, snap, npm, brew, gem, and a custom runner, and many more.

**Software Catalog:** Review [these tables](https://github.com/programmers/system_qa/blob/main/docs/Software/Software%20Docs.md) to see the full inventory of the software/packages.

**Technical:** Visit the [Development Guide](google.com) for exhaustive documentation and how to contribute!

**Workflow:** Clone, launch CLI, select ecosystems, answer questions, wait as OS dependencies are installed and Ansible runs.

**Release Tags:** Git release tags will be leveraged to capture and maintain new and old OS releases. Stability is key.

<br/>

## Development

Learn the internals of Programmer's System by following the comprehensive [Development Guide](google.com). It covers design, the Python codebase, the subset of Ansible features in use, and a break down of the modules. The format follows a "by example" convention.

Review the "Contributing" section to see how to be a part of this exciting project and community. **Contributors are welcomed!** See open issues.

<br/>

## Running

||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
<br/>
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
<br/>
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
<br/>
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
<br/>
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
<br/>
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
<br/>
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
<br/>
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
<br/>
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
<br/>
||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
<br/>

<br/>

```sh
# install git (https://git-scm.com/downloads)
git clone https://github.com/programmers/system_qa.git ~/.progsys
cd ~/run setup ubuntu

# options: ubuntu, xubuntu, mint-mate, mint-xfce, mint-cinnamon
```
<br/>

## Project TODOs

- Support Fedora 36
- Support MacOS Monterey/Ventura
- **Support ZSH/Oh My ZSH** (a pain)
- **Implement CI (vendor?)**
- **Add playbooks Scientific/Mobile/Ruby**
- Use loading indicators
- Generating SSH keys/git config
- Rethink "vars.yml" approach
- Spring Tool Suite not in search

<br/>

(this isn't well written) This is a new and exciting project aiming to significantly improve the developer "User Experience" unlike any other system out there. Your contributions will be appreciated in this young community. You can contribute by adding your favorite Linux and MacOS systems and/or improving existing playbooks and scripts. The existing code can be used as a reference to help you become productive in no time.

(Issue links to come)

## License

[MIT](https://github.com/programmers/system_qa/blob/main/LICENSE)