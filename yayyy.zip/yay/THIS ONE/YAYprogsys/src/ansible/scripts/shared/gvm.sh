#!/bin/bash

curl -sL https://raw.githubusercontent.com/moovweb/gvm/master/binscripts/gvm-installer | bash