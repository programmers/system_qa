# Programmer's System - ## Software and Packages Catalog

Many essential software and packages are installed outside of one's specific ecosystem CLI selections. Review the following complete list of what Programmer's System includes for your operating system:

<br/>

## General

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://code.visualstudio.com">VSCode</a></td>
      <td>Powerful and extensible source code editor</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://gnome-terminator.org/">Terminator</a></td>
      <td>Feature-full multi terminal emulator</td>
      <td>linux</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://www.gnu.org/software/screen">Screen</a></td>
      <td>Multiplexer that allows multiple terminal sessions to be accessed in a single window</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/tmux/tmux/wiki">Tmux</a></td>
      <td>Multiplexer that allows multiple terminal sessions to be accessed in a single window</td>
      <td>all</td>
      <td>ISC</td>
    </tr>
    <tr>
      <td><a href="https://www.vim.org/">Vim</a></td>
      <td>Powerful and extensible modal-based source code editor</td>
      <td>all</td>
      <td>VIM</td>
    </tr>
    <tr>
      <td><a href="https://www.gnu.org/software/emacs/">Emacs</a></td>
      <td>Powerful and extensible source code editor</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://htop.dev/">Htop</a></td>
      <td>Interactive system process viewer and process-manager</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/BurntSushi/ripgrep">ripgrep</a></td>
      <td>Fast grep/ag/ack alternative tool for line-oriented recursive searches</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/sharkdp/fd/">fd</a></td>
      <td>User-friendly alternative to find</td>
      <td>all</td>
      <td>Apache/MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/junegunn/fzf">fzf</a></td>
      <td>General-purpose fuzzy file finder</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/stedolan/jq">jq</a></td>
      <td>Command-line JSON processor</td>
      <td>all</td>
      <td>Many</td>
    </tr>
    <tr>
      <td><a href="https://github.com/nvbn/thefuck">thefuck</a></td>
      <td>Previously errored execution corrector</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/pmachapman/unrar">unrar</a></td>
      <td>RAR file archive extractor</td>
      <td>all</td>
      <td>Freeware</td>
    </tr>
    <tr>
      <td><a href="https://www.7-zip.org">7-Zip</a></td>
      <td>Nix port of the Windows 7-Zip file archiver</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/TizenTeam/dos2unix">dos2unix</a></td>
      <td>DOS text file to UNIX format convertor</td>
      <td>all</td>
      <td>BSD-like</td>
    </tr>
    <tr>
      <td><a href="https://gitlab.com/OldManProgrammer/unix-tree">tree</a></td>
      <td>Library for working with nested data structures</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/KDE/ghostwriter">ghostwriter</a></td>
      <td>Markdown editor</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
  </tbody>
</table>
<br/>

## Python

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.com/python/cpython">Python</a></td>
      <td>The Python programming language</td>
      <td>all</td>
      <td>BSD-like</td>
    </tr>
    <tr>
      <td><a href="https://github.com/microsoft/vscode-python">VSCode Python</a></td>
      <td>Primary Python VSCode extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com">IPython</a></td>
      <td>ipython</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/pypa/pipx">Pipx</a></td>
      <td>Package and environment management</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/PyCQA/flake8">Flake8</a></td>
      <td>Code formatter and more (wraps PyFlakes, pycodestyle, McCabe)</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/psf/black">Black</a></td>
      <td>Code formatter</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/pypa/pipenv">Pipenv</a></td>
      <td>Package and environment management</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/python-poetry/poetry">Poetry</a></td>
      <td>Package and environment management</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/pyenv/pyenv">Pyenv</a></td>
      <td>Version Manager</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://www.jetbrains.com/pycharm/download">PyCharm Community</a></td>
      <td>IDE</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
  </tbody>
</table>
<br/>

## JavaScript & Node

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.com/nodejs/node">Node</a></td>
      <td>Back-end JavaScript runtime environment</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/softchris/node-snippets">VSCode Node</a></td>
      <td>ES6 snippets that appear as selections as you type</td>
      <td>all</td>
      <td>Public/Free</td>
    </tr>
    <tr>
      <td><a href="https://github.com/xabikos/vscode-javascript">VSCode JavaScript</a></td>
      <td>ES6 snippets that appear as selections as you type</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/nvm-sh/nvm">Nvm</a></td>
      <td>Version manager</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/GoogleChromeLabs/ndb">Node Debugger</a></td>
      <td>Debugger</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://github.com/remy/nodemon">Nodemon</a></td>
      <td>File watcher that restarts Node applications when changes are detected</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/ChristianKohler/PathIntellisense">VSCode Path Intellisense</a></td>
      <td>Code file path autocomplete</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/TypeStrong/ts-node">TypeScript Node Engine</a></td>
      <td>TypeScript execution and REPL for Node</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/yarnpkg/yarn">Yarn</a></td>
      <td>Dependency manager</td>
      <td>all</td>
      <td>BSD</td>
    </tr>
    <tr>
      <td><a href="https://www.jetbrains.com/webstorm">WebStorm Trial</a></td>
      <td>JetBrains IDE trial</td>
      <td>all</td>
      <td>Non-free</td>
    </tr>
  </tbody>
</table>
<br/>

## Web

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.com/microsoft/vscode-eslint">VSCode ESLint</a></td>
      <td>VSCode ESLint extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/prettier/prettier-vscode">VSCode Prettier</a></td>
      <td>VSCode Prettier extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/pranaygp/vscode-css-peek">VSCode CSS Peek</a></td>
      <td>VSCode CSS peek extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/angular/angular-cli">Angular CLI</a></td>
      <td>Angular CLI</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/johnpapa/vscode-angular-essentials">VSCode Angular</a></td>
      <td>Primary Angular VSCode extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/vuejs/vue-cli">Vue CLI</a></td>
      <td>Vue CLI</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/sdras/vue-vscode-snippets">VSCode Vue</a></td>
      <td>Primary Vue VSCode extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/jawandarajbir/react-vscode-extension-pack">VSCode React</a></td>
      <td>Primary React VSCode extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/loiane/typescript-extension-pack-vscode">VSCode TypeScript</a></td>
      <td>Primary TypeScript VSCode extension</td>
      <td>all</td>
      <td>Public/Free</td>
    </tr>
    <tr>
      <td><a href="https://www.postman.com">Postman</a></td>
      <td>API testing application commonly used with REST APIs</td>
      <td>all</td>
      <td>Non-free</td>
    </tr>
    <tr>
      <td><a href="https://github.com/mockoon/mockoon">Mockoon</a></td>
      <td>Tool that offers granular control for mocking web services</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://ngrok.com">Ngrok</a></td>
      <td>Tool that makes your localhost accessible using Ngrok servers with many protocols</td>
      <td>all</td>
      <td>Non-free</td>
    </tr>
    <tr>
      <td><a href="https://github.com/localtunnel/localtunnel">localtunnel</a></td>
      <td>Tool that makes your localhost accessible using loca.lt servers</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/lwsjs/local-web-server">Local Web Server</a></td>
      <td>Featureful local web server that serves static, SPA, websockets apps, and more</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/Kong/insomnia">Insomnia</a></td>
      <td>API Client for GraphQL, REST, and gRPC</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
  </tbody>
</table>
<br/>

## Version Control

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.com/git/git">Git</a></td>
      <td>Distributed version control that supports many workflows</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/tj/git-extras">Git Extras</a></td>
      <td>Useful git commands</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/git-cola/git-cola">Git Cola</a></td>
      <td>Git GUI</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/GNOME/meld">Meld</a></td>
      <td>A visual diff and merge tool</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/KDE/kdiff3">KDiff3</a></td>
      <td>A visual diff and merge tool</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://www.mercurial-scm.org">Mercurial</a></td>
      <td>Distributed version control that supports many workflows</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://subversion.apache.org">Subversion</a></td>
      <td>Centralized version control system</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://savannah.nongnu.org/projects/cvs">CVS</a></td>
      <td>Traditional centralized version control system</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
  </tbody>
</table>
<br/>

## Database Clients

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://dbeaver.com">DBeaver Community</a></td>
      <td>Feature-packed tool that supports numerous databases for DBAs and developers</td>
      <td>all</td>
      <td>Non-free</td>
    </tr>
    <tr>
      <td><a href="https://github.com/xo/usql">Usql</a></td>
      <td>Tool that supports numerous databases from the command line</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://www.jetbrains.com/datagrip">Datagrip Trial</a></td>
      <td>JetBrains IDE trial</td>
      <td>all</td>
      <td>Non-free</td>
    </tr>
    <tr>
      <td><a href="https://www.mysql.com/products/workbench">MySQL Workbench Community</a></td>
      <td>Tool for MySQL DBAs and developers with a focus on modeling, general SQL use, and adminstration</td>
      <td>all</td>
      <td>Free/Non-free</td>
    </tr>
    <tr>
      <td><a href="https://github.com/dbcli/mycli">mycli</a></td>
      <td>Command line interface for MySQL and MariaDB</td>
      <td>all</td>
      <td>BSD</td>
    </tr>
    <tr>
      <td><a href="https://github.com/postgres/pgadmin4">pgAdmin 4 Desktop</a></td>
      <td>Tool for Postgres DBAs and developers with a focus on modeling, general SQL use, and adminstration</td>
      <td>all</td>
      <td>PostgreSQL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/dbcli/pgcli">pgcli</a></td>
      <td>Command line interface for Postgres</td>
      <td>all</td>
      <td>BSD</td>
    </tr>
    <tr>
      <td><a href="https://github.com/sqlitebrowser/sqlitebrowser">SQLite Browser</a></td>
      <td>GUI for the high performance and self-contained database SQLite data engine</td>
      <td>all</td>
      <td>GPL/MPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/joeferner/redis-commander">Redis Commander</a></td>
      <td>Web management tool supporting the typical Redis data structures</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/mongodb-js/compass">MongoDB Compass</a></td>
      <td>Official GUI for MongoDB</td>
      <td>all</td>
      <td>SSPL</td>
    </tr>
  </tbody>
</table>
<br/>

## Containers & VMs

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.com/moby/moby">Docker</a></td>
      <td>OS-level virtualization to deliver software in containers</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://github.com/microsoft/vscode-docker">VSCode Docker</a></td>
      <td>Primary Docker VSCode extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/docker/compose/blob/v2/LICENSE">Docker Compose</a></td>
      <td>Tool for defining and running multi-container Docker applications</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://github.com/qemu/qemu">Qemu/KVM/Virt</a></td>
      <td>Qemu/KVM and packages including the daemon and the manager/viewer software</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://www.virtualbox.org">VirtualBox</a></td>
      <td>Type-2 hypervisor that runs virtualized operating systems</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
  </tbody>
</table>
<br/>

## Cloud Tools

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.com/aws/aws-cli">AWS CLI</a></td>
      <td>Tool to manage AWS Cloud resources</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://github.com/twistedpair/google-cloud-sdk">Google Cloud CLI</a></td>
      <td>Tool to manage Google Cloud resources</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://github.com/Azure/azure-cli">Azure CLI</a></td>
      <td>Tool to manage Azure Cloud resources</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/digitalocean/doctl">Digital Ocean CLI</a></td>
      <td>Tool to manage DigitalOcean resources</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://github.com/kubernetes-sigs/kind">Kubernetes Kind</a></td>
      <td>Kubernetes in Docker is a tool for running local Kubernetes clusters</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://github.com/kubernetes/kubectl">Kubernetes Kubectl</a></td>
      <td>Tool to run commands against Kubernetes clusters</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://github.com/kubernetes/minikube">Kubernetes Minikube</a></td>
      <td>Tool for running a local Kubernetes cluster with many node management systems</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
  </tbody>
</table>
<br/>

## Java

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.com/openjdk/jdk">Java</a></td>
      <td>The Java programming language</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/microsoft/vscode-java-pack">VSCode Java</a></td>
      <td>Primary Java VSCode extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://maven.apache.org">Maven</a></td>
      <td>Automation tool for building, testing, deployment, and dependency management</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://github.com/gradle/gradle">Gradle</a></td>
      <td>Automation tool for building, testing, deployment, and dependency management</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://www.eclipse.org/eclipseid/">Eclipse</a></td>
      <td>Eclipse IDE for Java</td>
      <td>all</td>
      <td>EPL</td>
    </tr>
    <tr>
      <td><a href="https://spring.io/tools">Spring Tool Suite</a></td>
      <td>Spring Tool Suite</td>
      <td>all</td>
      <td>EPL</td>
    </tr>
    <tr>
      <td><a href="https://www.jetbrains.com/idea">IntelliJ IDEA Community</a></td>
      <td>IDE</td>
      <td>all</td>
      <td>Non-free</td>
    </tr>
    <tr>
      <td><a href="https://github.com/shyiko/jabba">Jabba Version Manager</a></td>
      <td>Version manager</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://ant.apache.org">Ant</a></td>
      <td>Build tool similar to make</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://ant.apache.org/ivy">Ivy</a></td>
      <td>Adds dependency management functionality to Ant</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
  </tbody>
</table>
<br/>

## C/C++

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://launchpad.net/build-essential">Build Essential</a></td>
      <td>GNU compilers, debuggers which include gcc, g++, and make</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://www.gnu.org/software/binutils">Binutils</a></td>
      <td>Tools for managing binary programs, objects, libraries, etc</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/llvm/llvm-project">Clang/LLVM</a></td>
      <td>C family compiler and related toolchains</td>
      <td>all</td>
      <td>BSD</td>
    </tr>
    <tr>
      <td><a href="https://github.com/Kitware/CMake">Cmake</a></td>
      <td>Build automation to generate makefiles</td>
      <td>all</td>
      <td>Multi</td>
    </tr>
    <tr>
      <td><a href="https://www.gnu.org/software/automake">Automake</a></td>
      <td>Tool used to generate Makefile.in files</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://www.gnu.org/software/autoconf/autoconf.html">Autoconf</a></td>
      <td>Tool used to produce artifacts for building and packaging software</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://www.gnu.org/software/libtool">Libtool</a></td>
      <td>An interface that eases using shared libraries in makefiles</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/microsoft/vscode-cpptools">VSCode C++</a></td>
      <td>Primary C++ VSCode extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://www.sourceware.org/gdb/">Gdb</a></td>
      <td>C family (and more) debugger</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://valgrind.org">Valgrind</a></td>
      <td>Tool for memory debugging, memory leak detection, and profiling</td>
      <td>all</td>
      <td>GPL</td>
    </tr>
    <tr>
      <td><a href="https://www.qt.io/product/development-tools">QT Creator</a></td>
      <td>Cross-platform C++ and JavaScript IDE which simplifies GUI application development</td>
      <td>all</td>
      <td>Multi</td>
    </tr>
    <tr>
      <td><a href="https://www.eclipse.org/downloads/packages/release/2022-06/r/eclipse-ide-cc-developers">Eclipse C/C++</a></td>
      <td>Eclipse IDE for C/C++</td>
      <td>all</td>
      <td>EPL</td>
    </tr>
    <tr>
      <td><a href="https://www.jetbrains.com/clion">CLion Trial</a></td>
      <td>JetBrains IDE trial</td>
      <td>all</td>
      <td>Non-free</td>
    </tr>
    <tr>
      <td><a href="http://www.codeblocks.org">Codeblocks</a></td>
      <td>C/C++ IDE built around a plugin framework details with plugins</td>
      <td>all</td>
      <td>LGPL/GPL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/boostorg/boost">Boost</a></td>
      <td>Useful libraries not found in standard C++, though sometimes influencing it</td>
      <td>all</td>
      <td>BSL</td>
    </tr>
    <tr>
      <td><a href="https://github.com/conan-io/conan">Conan</a></td>
      <td>C/C++ package manager</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/ninja-build/ninja">Ninja</a></td>
      <td>Small C/C++ build system with a high level abstraction</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
    <tr>
      <td><a href="https://mesonbuild.com/">Meson</a></td>
      <td>Fast and user friendly C/C++ build system</td>
      <td>all</td>
      <td>Apache</td>
    </tr>
  </tbody>
</table>
<br/>

## Go

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.com/golang/go">Go</a></td>
      <td>The Go programming language</td>
      <td>all</td>
      <td>BSD</td>
    </tr>
    <tr>
      <td><a href="https://github.com/moovweb/gvm">Go Version Manager</a></td>
      <td>Version manager</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/golang/vscode-go">VSCode Go</a></td>
      <td>Primary Go VSCode extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://www.jetbrains.com/goland">GoLand Trial</a></td>
      <td>JetBrains IDE trial</td>
      <td>all</td>
      <td>Non-free</td>
    </tr>
  </tbody>
</table>
<br/>

## PHP

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://www.php.net">PHP</a></td>
      <td>The PHP programming language</td>
      <td>all</td>
      <td>PHP</td>
    </tr>
    <tr>
      <td><a href="https://github.com/zobo/vscode-php-pack">VSCode PHP</a></td>
      <td>Primary PHP VSCode extension</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/phpenv/phpenv">Phpenv</a></td>
      <td>Version manager</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/composer/composer">Composer</a></td>
      <td>Package manager</td>
      <td>all</td>
      <td>MIT</td>
    </tr>
    <tr>
      <td><a href="https://www.eclipse.org/pdt">Eclipse PHP</a></td>
      <td>Eclipse IDE for PHP</td>
      <td>all</td>
      <td>EPL</td>
    </tr>
    <tr>
      <td><a href="https://www.jetbrains.com/phpstorm">PHPStorm Trial</a></td>
      <td>PHPStorm Trial</td>
      <td>all</td>
      <td>Non-free</td>
    </tr>
  </tbody>
</table>
<br/>

## Rust

<table>
  <thead>
    <th>Name</th>
    <th>About</th>
    <th>OS Support</th>
    <th>License</th>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://github.com/rust-lang/rust">Rust (via Rustup)</a></td>
      <td>The Rust programming language</td>
      <td>all</td>
      <td>Apache/MIT</td>
    </tr>
    <tr>
      <td><a href="https://github.com/rust-lang/vscode-rust">VSCode Rust</a></td>
      <td>Primary Rust VSCode extension</td>
      <td>all</td>
      <td>Apache/MIT</td>
    </tr>
  </tbody>
</table>